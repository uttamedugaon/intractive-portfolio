
import { useState } from 'react'
import {
  ArrowDown,
  ArrowDownRight,
  ArrowUpRight,
  CheckCircle2,
  Code2,
  ExternalLink,
  Layers3,
  Mail,
  Menu,
  Monitor,
  Palette,
  Send,
  Smartphone,
  X,
  Zap,
} from 'lucide-react'

const skills = [
  { name: 'HTML & CSS', level: 95, color: '#a78bfa' },
  { name: 'JavaScript', level: 85, color: '#67e8f9' },
  { name: 'React.js', level: 85, color: '#a78bfa' },
  { name: 'Tailwind CSS', level: 90, color: '#67e8f9' },
  { name: 'Responsive Design', level: 90, color: '#a78bfa' },
  { name: 'Git & GitHub', level: 75, color: '#67e8f9' },
]

const projects = [
  {
    number: '01',
    title: 'Nexora Landing Page',
    category: 'WEB DESIGN · REACT',
    description:
      'A modern, responsive agency landing page with service sections and clear calls to action.',
    icon: Monitor,
    color: '#a78bfa',
    bg: 'from-violet-500/20 via-purple-500/10 to-transparent',
    tags: ['React', 'Tailwind CSS', 'Responsive'],
  },
  {
    number: '02',
    title: 'TaskFlow App',
    category: 'PRODUCTIVITY · UI',
    description:
      'A clean task management interface concept designed to keep daily work organized.',
    icon: Layers3,
    color: '#67e8f9',
    bg: 'from-cyan-400/20 via-blue-500/10 to-transparent',
    tags: ['JavaScript', 'UI Design', 'Components'],
  },
  {
    number: '03',
    title: 'Creative Portfolio',
    category: 'PERSONAL BRAND · WEB',
    description:
      'A personal portfolio concept with animated elements and an interactive project gallery.',
    icon: Palette,
    color: '#f0abfc',
    bg: 'from-fuchsia-400/20 via-pink-500/10 to-transparent',
    tags: ['React', 'Animation', 'CSS'],
  },
]

const services = [
  {
    icon: Code2,
    title: 'Frontend Development',
    text: 'Building clean, reusable interfaces with React, JavaScript, and modern web tools.',
  },
  {
    icon: Palette,
    title: 'UI Implementation',
    text: 'Turning design concepts into polished, accessible, and consistent interfaces.',
  },
  {
    icon: Smartphone,
    title: 'Responsive Websites',
    text: 'Creating layouts that adapt smoothly to mobile, tablet, laptop, and desktop.',
  },
]

const navLinks = [
  ['About', '#about'],
  ['Skills', '#skills'],
  ['Projects', '#projects'],
  ['Contact', '#contact'],
]

function SectionTitle({ eyebrow, title, description }) {
  return (
    <div className="mb-12 max-w-2xl">
      <p className="mb-4 text-xs font-bold uppercase tracking-[0.25em] text-violet-300">
        {eyebrow}
      </p>
      <h2 className="font-['Manrope'] text-3xl font-extrabold tracking-tight text-white sm:text-4xl md:text-5xl">
        {title}
      </h2>
      {description && (
        <p className="mt-4 max-w-xl leading-7 text-zinc-400">{description}</p>
      )}
    </div>
  )
}

function App() {
  const [menuOpen, setMenuOpen] = useState(false)
  const [form, setForm] = useState({
    name: '',
    email: '',
    message: '',
  })
  const [status, setStatus] = useState('')

  function handleSubmit(event) {
    event.preventDefault()

    const subject = encodeURIComponent(
      `Portfolio enquiry from ${form.name}`
    )
    const body = encodeURIComponent(
      `Name: ${form.name}\nEmail: ${form.email}\n\nMessage:\n${form.message}`
    )

    setStatus('Your email application will open with your message.')
    window.location.href =
      `mailto:YOUR_EMAIL@example.com?subject=${subject}&body=${body}`
  }

  function updateForm(event) {
    setForm({ ...form, [event.target.name]: event.target.value })
    setStatus('')
  }

  return (
    <div className="min-h-screen overflow-x-clip bg-[#09090f] text-zinc-100">
      {/* NAVIGATION */}
      <header className="sticky top-0 z-50 border-b border-white/[0.07] bg-[#09090f]/90 backdrop-blur-xl">
        <nav className="section-wrap flex min-h-[76px] items-center justify-between gap-4">
          <a href="#home" className="flex shrink-0 items-center gap-2.5">
            <span className="flex h-10 w-10 items-center justify-center rounded-xl bg-violet-400 text-[#100d1c]">
              <Code2 size={22} />
            </span>
            <span className="font-['Manrope'] text-lg font-extrabold tracking-tight">
              Uttam<span className="text-violet-300"> Raj</span>
            </span>
          </a>

          <div className="hidden items-center gap-7 lg:flex">
            {navLinks.map(([label, href]) => (
              <a
                key={href}
                href={href}
                className="text-sm text-zinc-400 transition hover:text-violet-300"
              >
                {label}
              </a>
            ))}
          </div>

          <a
            href="#contact"
            className="hidden items-center gap-2 rounded-full border border-violet-300/30 px-5 py-2.5 text-sm font-semibold transition hover:bg-violet-400 hover:text-[#09090f] sm:flex"
          >
            Let's connect <ArrowUpRight size={16} />
          </a>

          <button
            type="button"
            onClick={() => setMenuOpen(!menuOpen)}
            aria-label={menuOpen ? 'Close menu' : 'Open menu'}
            aria-expanded={menuOpen}
            className="flex h-10 w-10 items-center justify-center rounded-xl border border-white/10 lg:hidden"
          >
            {menuOpen ? <X size={21} /> : <Menu size={21} />}
          </button>
        </nav>

        {menuOpen && (
          <div className="border-t border-white/10 bg-[#0d0d16] px-5 py-4 lg:hidden">
            <div className="section-wrap flex flex-col gap-1">
              {navLinks.map(([label, href]) => (
                <a
                  key={href}
                  href={href}
                  onClick={() => setMenuOpen(false)}
                  className="rounded-xl px-4 py-3 text-zinc-300 hover:bg-white/5 hover:text-violet-300"
                >
                  {label}
                </a>
              ))}
              <a
                href="#contact"
                onClick={() => setMenuOpen(false)}
                className="mt-2 rounded-xl bg-violet-400 px-4 py-3 text-center font-bold text-black"
              >
                Let's connect
              </a>
            </div>
          </div>
        )}
      </header>

      <main>
        {/* HERO */}
        <section id="home" className="relative grid-background">
          <div className="pointer-events-none absolute left-1/2 top-20 h-80 w-80 -translate-x-1/2 rounded-full bg-violet-600/10 blur-[100px]" />

          <div className="section-wrap relative grid items-center gap-14 py-20 sm:py-24 lg:grid-cols-[1.15fr_0.85fr] lg:gap-10 lg:py-32">
            <div className="reveal-up">
              <div className="mb-7 inline-flex items-center gap-2 rounded-full border border-violet-300/20 bg-violet-300/[0.07] px-4 py-2 text-xs font-medium text-violet-200">
                <span className="h-2 w-2 rounded-full bg-emerald-400" />
                OPEN TO OPPORTUNITIES
              </div>

              <p className="mb-4 text-sm font-semibold tracking-wide text-zinc-400">
                Hello, I'm
              </p>

              <h1 className="font-['Manrope'] text-5xl font-extrabold leading-[1.1] tracking-[-0.055em] sm:text-6xl lg:text-7xl xl:text-8xl">
                Uttam raj
                <span className="gradient-text block">Frontend</span>
                <span className="text-zinc-500">Developer.</span>
              </h1>

              <p className="mt-7 max-w-xl text-base leading-8 text-zinc-400 sm:text-lg">
                I build responsive, accessible, and engaging web experiences
                with React, JavaScript, and modern frontend technologies.
              </p>

              <div className="mt-9 flex flex-wrap gap-4">
                <a
                  href="#projects"
                  className="group inline-flex items-center gap-3 rounded-xl bg-violet-400 px-6 py-4 font-bold text-[#100d1c] transition hover:bg-violet-300"
                >
                  Explore projects
                  <ArrowDownRight size={19} className="transition group-hover:translate-x-1 group-hover:translate-y-1" />
                </a>
                <a
                  href="#contact"
                  className="inline-flex items-center gap-2 rounded-xl border border-white/15 px-6 py-4 font-semibold text-white transition hover:border-violet-300/50 hover:bg-white/5"
                >
                  Contact me <ArrowUpRight size={18} />
                </a>
              </div>

              <div className="mt-12 flex flex-wrap gap-x-7 gap-y-4 text-sm text-zinc-400">
                <span className="flex items-center gap-2">
                  <CheckCircle2 size={17} className="text-violet-300" />
                  Clean code
                </span>
                <span className="flex items-center gap-2">
                  <CheckCircle2 size={17} className="text-violet-300" />
                  Responsive UI
                </span>
                <span className="flex items-center gap-2">
                  <CheckCircle2 size={17} className="text-violet-300" />
                  Continuous learning
                </span>
              </div>
            </div>

            {/* CODE CARD */}
            <div className="relative mx-auto w-full max-w-md">
              <div className="absolute -inset-5 rounded-[2rem] bg-violet-500/10 blur-3xl" />

              <div className="glow relative overflow-hidden rounded-3xl border border-white/10 bg-[#101019]">
                <div className="flex items-center justify-between border-b border-white/10 px-5 py-4">
                  <div className="flex gap-2">
                    <span className="h-3 w-3 rounded-full bg-[#ff6b81]" />
                    <span className="h-3 w-3 rounded-full bg-[#f8c45c]" />
                    <span className="h-3 w-3 rounded-full bg-[#55d6a5]" />
                  </div>
                  <span className="text-xs text-zinc-500">developer.jsx</span>
                  <Code2 size={17} className="text-violet-300" />
                </div>

                <div className="overflow-x-auto p-5 font-mono text-xs leading-8 sm:p-7 sm:text-sm">
                  <p className="text-zinc-600">// A little about me</p>
                  <p>
                    <span className="text-fuchsia-300">const</span>{' '}
                    <span className="text-cyan-300">developer</span> = {'{'}
                  </p>
                  <p className="pl-4">
                    <span className="text-violet-300">name</span>:{' '}
                    <span className="text-emerald-300">'Uttam Raj'</span>,
                  </p>
                  <p className="pl-4">
                    <span className="text-violet-300">role</span>:{' '}
                    <span className="text-emerald-300">'Frontend Dev'</span>,
                  </p>
                  <p className="pl-4">
                    <span className="text-violet-300">skills</span>: [
                  </p>
                  <p className="pl-8 text-emerald-300">'React'</p>
                  <p className="pl-8 text-emerald-300">'JavaScript'</p>
                  <p className="pl-8 text-emerald-300">'Tailwind CSS'</p>
                  <p className="pl-4">],</p>
                  <p className="pl-4">
                    <span className="text-violet-300">mindset</span>:{' '}
                    <span className="text-emerald-300">'Always learning'</span>
                  </p>
                  <p>{'}'}</p>
                  <div className="mt-5 flex items-center gap-2 border-t border-white/10 pt-5 text-xs text-zinc-500">
                    <Zap size={15} className="text-violet-300" />
                    Turning ideas into interfaces
                  </div>
                </div>
              </div>

              <div className="absolute -bottom-5 -left-3 flex items-center gap-3 rounded-2xl border border-white/10 bg-[#171722] p-4 shadow-2xl sm:-left-8">
                <span className="flex h-10 w-10 items-center justify-center rounded-xl bg-violet-400/15 text-violet-300">
                  <Code2 size={20} />
                </span>
                <div>
                  <p className="text-sm font-bold">Build. Learn. Improve.</p>
                  <p className="mt-1 text-xs text-zinc-500">One project at a time</p>
                </div>
              </div>
            </div>
          </div>

          <a href="#about" className="mx-auto mb-8 flex w-fit items-center gap-2 text-xs text-zinc-500 transition hover:text-violet-300">
            SCROLL TO EXPLORE <ArrowDown size={14} />
          </a>
        </section>

        {/* ABOUT */}
        <section id="about" className="border-y border-white/[0.07] bg-[#0d0d15] py-20 sm:py-24">
          <div className="section-wrap">
            <SectionTitle
              eyebrow="01 — About me"
              title="Curious mind. Creative builder."
              description="I enjoy turning complex ideas into simple, intuitive digital experiences. My focus is on writing maintainable code and building interfaces that work well on every screen."
            />

            <div className="grid gap-5 md:grid-cols-3">
              {[
                {
                  icon: Code2,
                  title: 'Build with purpose',
                  text: 'I focus on readable, reusable components and thoughtful frontend architecture.',
                },
                {
                  icon: Palette,
                  title: 'Care about details',
                  text: 'Spacing, typography, accessibility, and interaction all matter.',
                },
                {
                  icon: Zap,
                  title: 'Keep improving',
                  text: 'Every project is an opportunity to learn, experiment, and grow.',
                },
              ].map(({ icon: Icon, title, text }) => (
                <article key={title} className="rounded-2xl border border-white/[0.08] bg-white/[0.025] p-6 transition duration-300 hover:-translate-y-1 hover:border-violet-300/30 hover:bg-violet-400/[0.04] sm:p-7">
                  <span className="flex h-12 w-12 items-center justify-center rounded-xl bg-violet-400/10 text-violet-300">
                    <Icon size={22} />
                  </span>
                  <h3 className="mt-6 text-lg font-bold">{title}</h3>
                  <p className="mt-3 text-sm leading-7 text-zinc-400">{text}</p>
                </article>
              ))}
            </div>
          </div>
        </section>

        {/* SKILLS */}
        <section id="skills" className="py-20 sm:py-24">
          <div className="section-wrap grid gap-12 lg:grid-cols-2 lg:gap-20">
            <div>
              <SectionTitle
                eyebrow="02 — My toolkit"
                title="Skills that bring ideas to life."
                description="Technologies and tools I use to create modern web interfaces. Progress bars are editable self-assessments—adjust them to match your actual skills."
              />

              <div className="flex flex-wrap gap-3">
                {['HTML5', 'CSS3', 'JavaScript', 'React', 'Tailwind CSS', 'Git', 'GitHub', 'Responsive Design', 'Java', 'Vite'].map((skill) => (
                  <span key={skill} className="rounded-xl border border-white/10 bg-white/[0.035] px-4 py-2.5 text-sm text-zinc-300 transition hover:border-violet-300/40 hover:text-violet-200">
                    {skill}
                  </span>
                ))}
              </div>
            </div>

            <div className="rounded-3xl border border-white/10 bg-[#101019] p-6 sm:p-8">
              <div className="mb-8 flex items-center gap-3">
                <span className="flex h-11 w-11 items-center justify-center rounded-xl bg-violet-400/10 text-violet-300">
                  <Code2 size={22} />
                </span>
                <div>
                  <h3 className="font-bold">Technical proficiency</h3>
                  <p className="mt-1 text-xs text-zinc-500">Personal skill assessment</p>
                </div>
              </div>

              <div className="space-y-6">
                {skills.map((skill) => (
                  <div key={skill.name}>
                    <div className="mb-2 flex items-center justify-between gap-4 text-sm">
                      <span className="font-medium text-zinc-300">{skill.name}</span>
                      <span className="text-zinc-500">{skill.level}%</span>
                    </div>
                    <div
                      className="h-2 overflow-hidden rounded-full bg-white/[0.07]"
                      role="progressbar"
                      aria-label={skill.name}
                      aria-valuenow={skill.level}
                      aria-valuemin={0}
                      aria-valuemax={100}
                    >
                      <div
                        className="h-full rounded-full transition-all duration-1000"
                        style={{ width: `${skill.level}%`, backgroundColor: skill.color }}
                      />
                    </div>
                  </div>
                ))}
              </div>
            </div>
          </div>
        </section>

        {/* PROJECTS */}
        <section id="projects" className="border-y border-white/[0.07] bg-[#0d0d15] py-20 sm:py-24">
          <div className="section-wrap">
            <SectionTitle
              eyebrow="03 — Selected work"
              title="Projects I'm proud to build."
              description="A showcase of frontend concepts and practice projects. Replace these examples with your actual work and repository links before submitting."
            />

            <div className="grid gap-6 md:grid-cols-2 lg:grid-cols-3">
              {projects.map((project) => {
                const Icon = project.icon

                return (
                  <article key={project.number} className="group overflow-hidden rounded-3xl border border-white/[0.08] bg-[#101019] transition duration-300 hover:-translate-y-2 hover:border-violet-300/30 hover:shadow-[0_20px_70px_-30px_rgba(167,139,250,0.3)]">
                    <div className={`relative flex aspect-[4/3] items-center justify-center overflow-hidden bg-gradient-to-br ${project.bg}`}>
                      <div className="absolute h-44 w-44 rounded-full border border-white/10 transition duration-500 group-hover:scale-125" />
                      <div className="absolute h-32 w-32 rotate-12 rounded-3xl border border-white/15 bg-white/[0.025] transition duration-500 group-hover:rotate-0" />
                      <div className="relative flex h-20 w-20 items-center justify-center rounded-2xl border border-white/15 bg-[#101019]/80 shadow-2xl transition duration-500 group-hover:scale-110" style={{ color: project.color }}>
                        <Icon size={34} />
                      </div>
                      <span className="absolute left-5 top-5 text-xs font-bold tracking-widest text-zinc-400">
                        PROJECT {project.number}
                      </span>
                      <span className="absolute right-5 top-5 rounded-full border border-white/10 bg-black/20 px-3 py-1 text-[10px] text-zinc-300">
                        CONCEPT
                      </span>
                    </div>

                    <div className="p-6">
                      <p className="text-[10px] font-bold tracking-[0.16em]" style={{ color: project.color }}>
                        {project.category}
                      </p>
                      <h3 className="mt-3 font-['Manrope'] text-xl font-extrabold">{project.title}</h3>
                      <p className="mt-3 min-h-[72px] text-sm leading-6 text-zinc-400">{project.description}</p>

                      <div className="mt-5 flex flex-wrap gap-2">
                        {project.tags.map((tag) => (
                          <span key={tag} className="rounded-lg bg-white/[0.05] px-2.5 py-1.5 text-[11px] text-zinc-400">
                            {tag}
                          </span>
                        ))}
                      </div>

                      <a
                        href="#contact"
                        className="mt-6 inline-flex items-center gap-2 text-sm font-semibold text-white transition hover:text-violet-300"
                      >
                        Discuss a project <ArrowUpRight size={16} />
                      </a>
                    </div>
                  </article>
                )
              })}
            </div>
          </div>
        </section>

        {/* SERVICES */}
        <section id="services" className="py-20 sm:py-24">
          <div className="section-wrap">
            <SectionTitle
              eyebrow="04 — What I do"
              title="From concept to clean code."
              description="Frontend-focused work that combines visual design, component architecture, and usability."
            />

            <div className="grid gap-5 md:grid-cols-3">
              {services.map(({ icon: Icon, title, text }) => (
                <article key={title} className="rounded-2xl border border-white/[0.08] p-6 transition hover:border-violet-300/30 hover:bg-white/[0.025] sm:p-7">
                  <Icon size={25} className="text-violet-300" />
                  <h3 className="mt-5 text-lg font-bold">{title}</h3>
                  <p className="mt-3 text-sm leading-7 text-zinc-400">{text}</p>
                </article>
              ))}
            </div>
          </div>
        </section>

        {/* CONTACT */}
        <section id="contact" className="border-t border-white/[0.07] bg-[#0d0d15] py-20 sm:py-24">
          <div className="section-wrap grid gap-12 lg:grid-cols-[0.9fr_1.1fr] lg:gap-20">
            <div>
              <SectionTitle
                eyebrow="05 — Get in touch"
                title="Have an idea? Let's talk."
                description="Looking for a frontend developer, have a project in mind, or want to connect? Send me a message."
              />

              <div className="space-y-4">
                <a href="mailto:YOUR_EMAIL@example.com" className="flex items-center gap-4 rounded-2xl border border-white/10 p-4 transition hover:border-violet-300/30">
                  <span className="flex h-11 w-11 items-center justify-center rounded-xl bg-violet-400/10 text-violet-300">
                    <Mail size={20} />
                  </span>
                  <span>
                    <span className="block text-xs text-zinc-500">Email me</span>
                    <span className="mt-1 block text-sm font-semibold">uttam.edugaon@gmail.com</span>
                  </span>
                  <ArrowUpRight size={17} className="ml-auto text-zinc-500" />
                </a>

                <a href="https://github.com/uttamedugaon" target="_blank" rel="noreferrer" className="flex items-center gap-4 rounded-2xl border border-white/10 p-4 transition hover:border-violet-300/30">
                  <span className="flex h-11 w-11 items-center justify-center rounded-xl bg-white/[0.06] text-white">
                    <Code2 size={20} />
                  </span>
                  <span>
                    <span className="block text-xs text-zinc-500">Code & repositories</span>
                    <span className="mt-1 block text-sm font-semibold">GitHub profile</span>
                  </span>
                  <ExternalLink size={16} className="ml-auto text-zinc-500" />
                </a>

                <a href="https://www.linkedin.com/in/uttam-raj01" target="_blank" rel="noreferrer" className="flex items-center gap-4 rounded-2xl border border-white/10 p-4 transition hover:border-violet-300/30">
                  <span className="flex h-11 w-11 items-center justify-center rounded-xl bg-white/[0.06] text-white">
                    <ExternalLink size={20} />
                  </span>
                  <span>
                    <span className="block text-xs text-zinc-500">Professional network</span>
                    <span className="mt-1 block text-sm font-semibold">LinkedIn profile</span>
                  </span>
                  <ExternalLink size={16} className="ml-auto text-zinc-500" />
                </a>
              </div>
            </div>

            <form onSubmit={handleSubmit} className="rounded-3xl border border-white/10 bg-[#101019] p-5 sm:p-8">
              <h3 className="text-xl font-extrabold">Send a message</h3>
              <p className="mt-2 text-sm text-zinc-500">All fields are required.</p>

              <div className="mt-7 space-y-5">
                <div>
                  <label htmlFor="name" className="mb-2 block text-sm font-medium text-zinc-300">Your name</label>
                  <input
                    id="name"
                    name="name"
                    value={form.name}
                    onChange={updateForm}
                    required
                    maxLength={100}
                    autoComplete="name"
                    placeholder="Enter your name"
                    className="w-full rounded-xl border border-white/10 bg-[#09090f] px-4 py-3.5 text-sm outline-none transition placeholder:text-zinc-600 focus:border-violet-300/60"
                  />
                </div>

                <div>
                  <label htmlFor="email" className="mb-2 block text-sm font-medium text-zinc-300">Email address</label>
                  <input
                    id="email"
                    type="email"
                    name="email"
                    value={form.email}
                    onChange={updateForm}
                    required
                    maxLength={254}
                    autoComplete="email"
                    placeholder="you@example.com"
                    className="w-full rounded-xl border border-white/10 bg-[#09090f] px-4 py-3.5 text-sm outline-none transition placeholder:text-zinc-600 focus:border-violet-300/60"
                  />
                </div>

                <div>
                  <label htmlFor="message" className="mb-2 block text-sm font-medium text-zinc-300">Your message</label>
                  <textarea
                    id="message"
                    name="message"
                    value={form.message}
                    onChange={updateForm}
                    required
                    maxLength={3000}
                    rows={5}
                    placeholder="Tell me about your idea..."
                    className="w-full resize-y rounded-xl border border-white/10 bg-[#09090f] px-4 py-3.5 text-sm outline-none transition placeholder:text-zinc-600 focus:border-violet-300/60"
                  />
                </div>

                <button type="submit" className="flex w-full items-center justify-center gap-2 rounded-xl bg-violet-400 px-5 py-4 font-bold text-[#100d1c] transition hover:bg-violet-300">
                  Open email to send <Send size={17} />
                </button>

                {status && (
                  <p role="status" className="text-sm leading-6 text-violet-200">
                    {status}
                  </p>
                )}

                <p className="text-xs leading-5 text-zinc-500">
                  This demo uses your email application. It does not store messages on a server. Configure your own email address before publishing.
                </p>
              </div>
            </form>
          </div>
        </section>
      </main>

      {/* FOOTER */}
      <footer className="border-t border-white/[0.07]">
        <div className="section-wrap flex flex-col gap-5 py-7 sm:flex-row sm:items-center sm:justify-between">
          <a href="#home" className="flex items-center gap-2 font-['Manrope'] font-extrabold">
            <Code2 size={20} className="text-violet-300" />
            Uttam<span className="text-violet-300">raj.</span>
          </a>

          <p className="text-sm text-zinc-500">
            © {new Date().getFullYear()} Uttam raj. Built with React.
          </p>

          <a href="#home" className="inline-flex items-center gap-2 text-sm text-zinc-400 transition hover:text-violet-300">
            Back to top <ArrowUpRight size={16} />
          </a>
        </div>
      </footer>
    </div>
  )
}

export default App
